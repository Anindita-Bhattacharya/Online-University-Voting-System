
import java.sql.*;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class registration
 */
@WebServlet("/registration")
public class registration extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
       Connection con;
       PreparedStatement pst;
       PreparedStatement pst1;
       
       
       
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	
		try 
		{
			response.setContentType("text/html");
			PrintWriter out=response.getWriter();
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost/oce","root","root");
			String name=request.getParameter("name");
			String email=request.getParameter("email");
			String password=request.getParameter("password");
			String gender=request.getParameter("gender");
			String username=request.getParameter("username");
			String number=request.getParameter("number");
			pst=con.prepareStatement("insert into user(name,email,password,gender,username,phone) values(?,?,?,?,?,?)");
			pst.setString(1, name);
			pst.setString(2, email);
			pst.setString(3, password);
			pst.setString(4, gender);
			pst.setString(5, username);
			pst.setString(6, number);
			pst.executeUpdate();
			//out.println("Successfuly Registration has been done");
			response.sendRedirect("signup.html");
			
			
			
			
			
			
			//out.println(name);
			//out.println(username);
			//out.println(email);
			//out.println(number);
			//out.println(password);
			//out.println(gender);
			
		
			
			
			
		    }
		catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
