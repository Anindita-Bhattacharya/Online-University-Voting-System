

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;


/**
 * Servlet implementation class helloservlet
 */
@WebServlet("/helloservlet")
public class helloservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private static Connection com;
    private String password;
    private String email;
    private static final String Database_URL="jdbc:mysql://localhost/oce";
    private static final String oce_usr="root";
    private static final String oce_password="root";
    
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public helloservlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out=response.getWriter();

		email=request.getParameter("email");
		password=request.getParameter("password");
		
		boolean result=checkPassword(email,password);
		out.println("<html>");
		out.println("<body>");
		if(result==true)
		{
			//out.println("Hi" +email);
		    response.sendRedirect("navbar.jsp");

		}
		else
		{
			out.println("Invalid username or password");
		}
		out.println("</body></html>");
		out.close();
		
		
	}
	protected boolean checkPassword(String email,String password)
	{
		String correctPassword=null;
		try
		{
			try
			{
				
				Class.forName("com.mysql.jdbc.Driver");
				com=DriverManager.getConnection("jdbc:mysql://localhost/oce","root","root");
				com.setAutoCommit(true);
			}
			catch(Exception e)
			{
				System.out.println("Connection failed"+e.toString());
			}
			Statement  statement=com.createStatement();
			statement.executeQuery("select password from user where email='"+email+"'");
			ResultSet rs=statement.getResultSet();
			if(rs.next())
			{
				correctPassword=rs.getString(1);
				
			}
			statement.close();
			if(correctPassword.equals(password))
			{
				return true;
				
			}
			else
			{
				return false;
			}
		}
		catch(Exception e)
		{
			System.out.println("Exception in verifyPassword()="+e.toString());
			return false;
		}
		
	}

}
